package top.aihmc.omnimorph.backend2.protocol;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/** Bounded reassembly and ordered writes for a single immutable connection scope. */
public final class CloudSocket implements WebSocket.Listener, AutoCloseable {
    private final Consumer<byte[]> receive;
    private final Consumer<String> failure;
    private final int limit;
    private final CloudEndpoint endpoint;
    private final boolean textOnly;
    private final ByteArrayOutputStream incoming = new ByteArrayOutputStream();
    private final StringBuilder incomingText = new StringBuilder();
    private CompletableFuture<WebSocket> writes;
    private WebSocket socket;
    private boolean closed;
    private int queuedBytes;
    private int queuedMessages;

    public CloudSocket(int limit, Consumer<byte[]> receive, Consumer<String> failure) {
        this(limit, receive, failure, null);
    }

    public CloudSocket(int limit, Consumer<byte[]> receive, Consumer<String> failure, CloudEndpoint endpoint) {
        this(limit, receive, failure, endpoint, false);
    }

    public CloudSocket(int limit, Consumer<byte[]> receive, Consumer<String> failure,
                       CloudEndpoint endpoint, boolean textOnly) {
        this.endpoint = endpoint;
        this.textOnly = textOnly;
        this.limit = limit;
        this.receive = receive;
        this.failure = failure;
    }

    public synchronized void attach(WebSocket socket) throws IOException {
        if (endpoint != null) {
            try {
                endpoint.requireAllowed();
            } catch (IOException rejected) {
                socket.abort();
                throw rejected;
            }
        }
        if (closed) {
            socket.abort();
            throw new IOException("Connection retired");
        }
        this.socket = socket;
        writes = CompletableFuture.completedFuture(socket);
    }

    public synchronized boolean send(byte[] bytes) throws IOException {
        return send(bytes, false);
    }

    public synchronized void sendText(String text) throws IOException {
        send(text.getBytes(StandardCharsets.UTF_8), true);
    }

    private boolean send(byte[] bytes, boolean text) throws IOException {
        if (endpoint != null) {
            endpoint.requireAllowed();
        }
        if (closed || socket == null || bytes.length > limit || text != textOnly) {
            throw new IOException("Socket unavailable or message exceeds budget");
        }
        if (queuedMessages >= 32 || queuedBytes + bytes.length > 262144) {
            throw new IOException("Socket queue requires recovery");
        }
        queuedMessages++;
        queuedBytes += bytes.length;
        byte[] copy = bytes.clone();
        writes = writes.thenCompose(current -> {
            try {
                synchronized (this) {
                    if (closed) {
                        throw new IOException("Connection retired");
                    }
                    if (endpoint != null) {
                        endpoint.requireAllowed();
                    }
                    return text ? current.sendText(new String(copy, StandardCharsets.UTF_8), true)
                            : current.sendBinary(ByteBuffer.wrap(copy), true);
                }
            } catch (IOException rejected) {
                return CompletableFuture.failedFuture(rejected);
            }
        })
                .orTimeout(5, TimeUnit.SECONDS);
        writes.whenComplete((ignored, error) -> {
            synchronized (this) {
                queuedMessages--;
                queuedBytes -= copy.length;
            }
            if (error != null) {
                CompletableFuture.runAsync(() -> fail("Socket write failed"));
            }
        });
        return true;
    }

    @Override
    public void onOpen(WebSocket socket) {
        socket.request(1);
    }

    @Override
    public CompletableFuture<?> onBinary(WebSocket socket, ByteBuffer bytes, boolean last) {
        try {
            if (textOnly) {
                throw new IOException("Unexpected binary message");
            }
            if (endpoint != null) {
                endpoint.requireAllowed();
            }
            byte[] complete = null;
            synchronized (this) {
                if (closed) {
                    return CompletableFuture.completedFuture(null);
                }
                if (bytes.remaining() > limit - incoming.size()) {
                    throw new IOException("Socket message exceeds budget");
                }
                byte[] fragment = new byte[bytes.remaining()];
                bytes.get(fragment);
                incoming.write(fragment);
                if (last) {
                    complete = incoming.toByteArray();
                    incoming.reset();
                }
            }
            if (complete != null) {
                receive.accept(complete);
            }
        } catch (Exception exception) {
            fail("Invalid socket message");
        }
        socket.request(1);
        return CompletableFuture.completedFuture(null);
    }

    @Override
    public CompletableFuture<?> onText(WebSocket socket, CharSequence text, boolean last) {
        try {
            if (!textOnly) {
                throw new IOException("Unexpected text message");
            }
            if (endpoint != null) {
                endpoint.requireAllowed();
            }
            byte[] complete = null;
            synchronized (this) {
                if (closed) {
                    return CompletableFuture.completedFuture(null);
                }
                if (text.length() > limit - incomingText.length()) {
                    throw new IOException("Socket message exceeds budget");
                }
                incomingText.append(text);
                if (last) {
                    complete = incomingText.toString().getBytes(StandardCharsets.UTF_8);
                    incomingText.setLength(0);
                    if (complete.length > limit) {
                        throw new IOException("Socket message exceeds budget");
                    }
                }
            }
            if (complete != null) {
                receive.accept(complete);
            }
        } catch (Exception exception) {
            fail("Invalid socket message");
        }
        socket.request(1);
        return CompletableFuture.completedFuture(null);
    }

    @Override
    public CompletableFuture<?> onClose(WebSocket socket, int statusCode, String reason) {
        fail("Socket closed: " + statusCode);
        return CompletableFuture.completedFuture(null);
    }

    @Override
    public void onError(WebSocket socket, Throwable error) {
        fail("Socket connection failed");
    }

    private void fail(String reason) {
        synchronized (this) {
            if (closed) {
                return;
            }
            closed = true;
        }
        close();
        failure.accept(reason);
    }

    @Override
    public synchronized void close() {
        closed = true;
        incoming.reset();
        incomingText.setLength(0);
        if (socket != null) {
            socket.abort();
        }
        if (writes != null) {
            writes.cancel(true);
        }
    }
}
