package org.figuramc.figura.gui.widgets;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import org.figuramc.figura.utils.FiguraIdentifier;
import org.figuramc.figura.utils.MathUtils;
import org.figuramc.figura.utils.ui.UIHelper;

public class ScrollBarWidget extends AbstractWidget implements FiguraWidget {

    // -- fields -- // 

    public static final Identifier SCROLLBAR_TEXTURE = new FiguraIdentifier("textures/gui/scrollbar.png");

    protected final int headHeight;
    protected final int headWidth;

    protected boolean isScrolling = false;
    protected boolean vertical = true;

    protected double scrollPos;
    protected double scrollPrecise;
    protected double scrollRatio = 1d;

    protected OnPress onPress;

    // -- constructors -- // 

    public ScrollBarWidget(int x, int y, int width, int height, double initialValue) {
        this(x, y, width, height, initialValue, true);
    }

    public ScrollBarWidget(int x, int y, int width, int height, double initialValue, boolean vertical) {
        super(x, y, width, height, Component.empty());
        this.vertical = vertical;
        headWidth = vertical ? 10 : 20;
        headHeight = vertical ? 20 : 10;
        scrollPrecise = initialValue;
        scrollPos = initialValue;
    }

    // -- methods -- // 


    @Override
    public boolean mouseClicked(MouseButtonEvent mouseButtonEvent, boolean bl) {
        if (!this.isActive() || !this.isHoveredOrFocused() || !this.isMouseOver(mouseButtonEvent.x(), mouseButtonEvent.y()))
            return false;

        if (mouseButtonEvent.button() == 0) {
            double mouseX = mouseButtonEvent.x();
            double mouseY = mouseButtonEvent.y();
            // jump to pos when not clicking on head
            double scrollPos = Mth.lerp(scrollPrecise, 0d, (vertical ? getHeight() - headHeight : getWidth() - headWidth) + 2d);

            double coordinate = vertical ? mouseY : mouseX;
            double start = vertical ? getY() : getX();
            int headSize = vertical ? headHeight : headWidth;
            if (coordinate < start + scrollPos || coordinate > start + scrollPos + headSize) {
                scroll(coordinate - start - scrollPos - headSize / 2d);
            }

            isScrolling = true;
            playDownSound(Minecraft.getInstance().getSoundManager());
            return true;
        }

        return super.mouseClicked(mouseButtonEvent, bl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent mouseButtonEvent) {
        if (mouseButtonEvent.button() == 0 && isScrolling) {
            isScrolling = false;
            return true;
        }

        return false;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent mouseButtonEvent, double deltaX, double deltaY) {
        double mouseX = mouseButtonEvent.x();
        double mouseY = mouseButtonEvent.y();
        if (isScrolling) {
            // vertical drag
            if (vertical) {
                if (Math.signum(deltaY) == -1) {
                    if (mouseY <= this.getY() + this.getHeight()) {
                        scroll(deltaY);
                        return true;
                    }

                } else if (mouseY >= this.getY()) {
                    scroll(deltaY);
                    return true;
                }
            }
            // horizontal drag
            else if (Math.signum(deltaX) == -1) {
                if (mouseX <= this.getX() + this.getWidth()) {
                    scroll(deltaX);
                    return true;
                }
            } else if (mouseX >= this.getX()) {
                scroll(deltaX);
                return true;
            }
        }

        return super.mouseDragged(mouseButtonEvent, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount, double d) {
        if (!this.isActive()) return false;
        scroll(-amount-d * (vertical ? getHeight() : getWidth()) * 0.05d * scrollRatio);
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent keyEvent) {
        if (!this.isActive()) return false;

        int keyCode = keyEvent.key();
        if (keyCode > 261 && keyCode < 266) {
            scroll((keyCode % 2 == 0 ? 1 : -1) * (vertical ? getHeight() : getWidth()) * 0.05d * scrollRatio);
            return true;
        }

        return super.keyPressed(keyEvent);
    }

    @Override
    public boolean isMouseOver(double mouseX, double mouseY) {
        return UIHelper.isMouseOver(getX(), getY(), getWidth(), getHeight(), mouseX, mouseY);
    }

    // apply scroll value
    protected void scroll(double amount) {
        scrollPrecise += amount / ((vertical ? getHeight() - headHeight : getWidth() - headWidth) + 2d);
        setScrollProgress(scrollPrecise);
    }

    // animate scroll head
    protected void lerpPos(float delta) {
        float lerpDelta = MathUtils.magicDelta(0.2f, delta);
        scrollPos = Mth.lerp(lerpDelta, scrollPos, getScrollProgress());
    }

    @Override
    public void extractWidgetRenderState(GuiGraphicsExtractor gui, int mouseX, int mouseY, float delta) {
        if (!isVisible())
            return;

        isHovered = this.isMouseOver(mouseX, mouseY);

        // render the scroll
        UIHelper.enableBlend();
        lerpPos(delta);
        if (vertical) {
            renderBar(gui, getX(), getY(), getWidth(), getHeight());
        } else {
            gui.pose().pushMatrix();
            gui.pose().translate(getX(), getY() + getHeight());
            gui.pose().rotate(-(float) Math.PI / 2f);
            renderBar(gui, 0, 0, getHeight(), getWidth());
            gui.pose().popMatrix();
        }
    }

    private void renderBar(GuiGraphicsExtractor gui, int x, int y, int width, int height) {
        int renderedHeadWidth = vertical ? headWidth : headHeight;
        int renderedHeadHeight = vertical ? headHeight : headWidth;
        gui.blit(RenderPipelines.GUI_TEXTURED, SCROLLBAR_TEXTURE, x, y, 10f,
                isScrolling ? 20f : 0f, width, 1, 10, 1, 20, 40);
        gui.blit(RenderPipelines.GUI_TEXTURED, SCROLLBAR_TEXTURE, x, y + 1, 10f,
                isScrolling ? 21f : 1f, width, height - 2, 10, 18, 20, 40);
        gui.blit(RenderPipelines.GUI_TEXTURED, SCROLLBAR_TEXTURE, x, y + height - 1, 10f,
                isScrolling ? 39f : 19f, width, 1, 10, 1, 20, 40);

        int headY = y + (int) Math.round(Mth.lerp(scrollPos, 0, height - renderedHeadHeight));
        gui.blit(RenderPipelines.GUI_TEXTURED, SCROLLBAR_TEXTURE, x, headY, 0f,
                isHoveredOrFocused() || isScrolling ? renderedHeadHeight : 0f,
                renderedHeadWidth, renderedHeadHeight, 20, 40);
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput builder) {
    }

    // -- getters and setters -- // 

    @Override
    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    @Override
    public int getX() {
        return super.getX();
    }

    @Override
    public void setX(int x) {
        super.setX(x);
    }

    @Override
    public int getY() {
        return super.getY();
    }

    @Override
    public void setY(int y) {
        super.setY(y);
    }

    @Override
    public int getWidth() {
        return super.getWidth();
    }

    @Override
    public void setWidth(int width) {
        super.setWidth(width);
    }

    @Override
    public int getHeight() {
        return super.getHeight();
    }

    // set scrollbar height
    @Override
    public void setHeight(int height) {
        this.height = height;
    }

    @Override
    public boolean isActive() {
        return this.active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    // get scroll value
    public double getScrollProgress() {
        return scrollPrecise;
    }

    // manually set scroll
    public void setScrollProgress(double amount) {
        setScrollProgress(amount, false);
    }

    public void setScrollProgressNoAnim(double amount) {
        setScrollProgress(amount, false);
        scrollPos = scrollPrecise;
    }

    // manually set scroll with optional clamping
    public void setScrollProgress(double amount, boolean force) {
        amount = Double.isNaN(amount) ? 0 : amount;
        scrollPrecise = force ? amount : Mth.clamp(amount, 0d, 1d);

        if (onPress != null)
            onPress.onPress(this);
    }

    // set button action
    public void setAction(OnPress onPress) {
        this.onPress = onPress;
    }

    // set scroll ratio
    public void setScrollRatio(double entryHeight, double heightDiff) {
        scrollRatio = (getHeight() + entryHeight) / (heightDiff / 2d);
    }

    // press action
    public interface OnPress {
        void onPress(ScrollBarWidget scrollbar);
    }
}
