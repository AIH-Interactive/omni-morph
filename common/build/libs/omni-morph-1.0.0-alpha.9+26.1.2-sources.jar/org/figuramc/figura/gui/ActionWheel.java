package org.figuramc.figura.gui;

import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import org.figuramc.figura.FiguraMod;
import org.figuramc.figura.avatar.Avatar;
import org.figuramc.figura.avatar.AvatarManager;
import org.figuramc.figura.avatar.UserData;
import top.aihmc.omnimorph.model.outfit.OutfitActionWheel;
import org.figuramc.figura.config.Configs;
import org.figuramc.figura.font.Emojis;
import org.figuramc.figura.lua.api.action_wheel.Action;
import org.figuramc.figura.lua.api.action_wheel.Page;
import top.aihmc.omnimorph.model.ysm.action.YsmActionRuntime;
import org.figuramc.figura.math.vector.FiguraVec3;
import org.figuramc.figura.math.vector.FiguraVec4;
import org.figuramc.figura.utils.ColorUtils;
import org.figuramc.figura.utils.FiguraIdentifier;
import org.figuramc.figura.utils.FiguraText;
import org.figuramc.figura.utils.TextUtils;
import org.figuramc.figura.utils.ui.UIHelper;
import org.joml.Matrix3x2fStack;

import java.util.List;
import java.util.function.Function;

public class ActionWheel {

    private static final Identifier TEXTURE = new FiguraIdentifier("textures/gui/action_wheel.png");
    private static final Identifier ICONS = new FiguraIdentifier("textures/gui/action_wheel_icons.png");
    private static final double DISTANCE = 41;
    private static final double DEADZONE = 19;

    private static boolean enabled = false;
    private static int selected = -1;
    private static final YsmActionRuntime.Press YSM_PRESS =
            new YsmActionRuntime.Press();
    private static OutfitActionWheel outfitWheel;

    private static UserData.OutfitState currentOutfit() {
        var state = AvatarManager.getLoadedOutfit(FiguraMod.getLocalPlayerUUID());
        var next = state == null ? null : state.composition().actionWheel();
        if (outfitWheel != next && outfitWheel != null) {
            outfitWheel.release();
        }
        outfitWheel = next;
        return state;
    }

    private static void withOutfitBudget(UserData.OutfitState outfit, Runnable action) {
        if (outfit.base() == null) {
            action.run();
        } else {
            outfit.composition().withBaseBudget(outfit.base(), action);
        }
    }

    // rendering data
    private static Minecraft minecraft;
    private static int slots, leftSlots, rightSlots;
    private static float scale;
    private static int x, y;
    private static double mouseX, mouseY;

    /** Preview draws reuse the native wheel artwork without changing the player's active wheel state. */
    private record RenderState(Minecraft client, int count, int left, int right, float wheelScale,
                               int centerX, int centerY, double pointerX, double pointerY, int selection) {
        private static RenderState capture() {
            return new RenderState(minecraft, slots, leftSlots, rightSlots, scale, x, y, mouseX, mouseY, selected);
        }

        private void restore() {
            minecraft = client;
            slots = count;
            leftSlots = left;
            rightSlots = right;
            scale = wheelScale;
            x = centerX;
            y = centerY;
            mouseX = pointerX;
            mouseY = pointerY;
            selected = selection;
        }
    }

    public static void renderPreview(GuiGraphicsExtractor gui, Page page, int centerX, int centerY,
                                     double pointerX, double pointerY) {
        if (page == null) {
            return;
        }
        RenderState previous = RenderState.capture();
        try {
            minecraft = Minecraft.getInstance();
            x = centerX;
            y = centerY;
            scale = Configs.ACTION_WHEEL_SCALE.value;
            slots = page.getSize();
            leftSlots = slots / 2;
            rightSlots = (slots + 1) / 2;
            mouseX = pointerX;
            mouseY = pointerY;
            calculateSelected();
            var pose = gui.pose();
            pose.pushMatrix();
            try {
                pose.translate(x, y);
                pose.scale(scale, scale);
                renderTextures(gui, page);
                renderItemsAndIcons(gui, page);
            } finally {
                pose.popMatrix();
            }
            renderTexts(gui, page);
        } finally {
            previous.restore();
        }
    }

    public static int previewSelection(Page page, int centerX, int centerY, double pointerX, double pointerY) {
        if (page == null) {
            return -1;
        }
        int count = page.getSize();
        return selection(centerX, centerY, Configs.ACTION_WHEEL_SCALE.value, pointerX, pointerY,
                count / 2, (count + 1) / 2);
    }

    public static void render(GuiGraphicsExtractor gui) {
        if (!isEnabled()) return;

        minecraft = Minecraft.getInstance();
        Window window = minecraft.getWindow();
        x = (int) (window.getGuiScaledWidth() / 2d);
        y = (int) (window.getGuiScaledHeight() / 2d);

        // rendering
        Matrix3x2fStack pose = gui.pose();
        pose.pushMatrix();
        pose.translate(x, y);

        scale = Configs.ACTION_WHEEL_SCALE.value;
        pose.scale(scale, scale);

        var outfit = currentOutfit();
        Avatar avatar = outfit == null ? AvatarManager.getAvatarForPlayer(FiguraMod.getLocalPlayerUUID()) : outfit.base();
        Page currentPage = outfit != null ? outfitWheel.page(avatar)
                : avatar == null || avatar.luaRuntime == null ? null : avatar.luaRuntime.action_wheel.currentPage;
        if (currentPage == null) {
            // this also pops the stack
            renderEmpty(gui, avatar == null);
            return;
        }

        // get left and right slots, right side have preference when the slots its odd
        slots = currentPage.getSize();
        leftSlots = (int) Math.floor(slots / 2d);
        rightSlots = (int) Math.ceil(slots / 2d);

        mouseX = minecraft.mouseHandler.xpos() * window.getGuiScaledWidth() / window.getScreenWidth();
        mouseY = minecraft.mouseHandler.ypos() * window.getGuiScaledHeight() / window.getScreenHeight();

        // calculate selected slot
        FiguraMod.pushProfiler("selectedSlot");
        calculateSelected();

        // render overlays
        FiguraMod.popPushProfiler("wheel");
        renderTextures(gui, currentPage);

        // reset colours, no longer needed, color is handled through vertex now
        //RenderSystem.setShaderColor(1f, 1f, 1f, 1f);

        // render items
        FiguraMod.popPushProfiler("items");
        renderItemsAndIcons(gui, currentPage);

        pose.popMatrix();

        // render title
        FiguraMod.popPushProfiler("texts");
        renderTexts(gui, currentPage);

        FiguraMod.popProfiler();
    }

    // -- render helpers -- // 

    private static double getAngle(int i) {
        double angle;
        if (i < rightSlots)
            angle = 180d / rightSlots * (i - ((rightSlots - 1) * 0.5));
        else
            angle = 180d / leftSlots * (i - rightSlots - ((leftSlots - 1) * 0.5f) + leftSlots);

        return Math.toRadians(angle);
    }

    private static void renderEmpty(GuiGraphicsExtractor gui, boolean avatar) {
        // render empty wheel
        TextureData data = OverlayTexture.values()[0].data[0];
        data.render(gui, null, false);
        data.render(gui, null, true);

        gui.pose().popMatrix(); // previous stack

        // warning text
        Component component = FiguraText.of("gui.error." + (avatar ? "no_avatar" : "no_wheel_page")).withStyle(ChatFormatting.YELLOW);
        Font font = minecraft.font;

        UIHelper.renderOutlineText(gui, font, component, x - font.width(component) / 2, y - font.lineHeight / 2, 0xFFFFFF, 0);
    }

    private static void calculateSelected() {
        selected = selection(x, y, scale, mouseX, mouseY, leftSlots, rightSlots);
    }

    private static int selection(int x, int y, float scale, double mouseX, double mouseY,
                                 int leftSlots, int rightSlots) {
        // get the total mouse distance from the center of the wheel
        double mouseDistance = Math.sqrt(Math.pow(x - mouseX, 2) + Math.pow(y - mouseY, 2));

        // no need to sum left side because if the right side is 0, the left side will also be 0
        if (rightSlots == 0 || mouseDistance < (DEADZONE * scale)) {
            return -1;
        }

        // get the mouse angle in degrees from middle of the wheel, starting at top, clockwise
        double angle = Math.toDegrees(Math.atan2(mouseY - y, mouseX - x)) + 90;
        if (angle < 0) angle += 360;

        // get the selected slot
        if (angle < 180)
            return (int) Math.floor((rightSlots / 180d) * angle);
        else
            return (int) Math.floor((leftSlots / 180d) * (angle - 180)) + rightSlots;
    }

    private static void renderTextures(GuiGraphicsExtractor gui, Page page) {
        for (int i = 0; i < slots; i++) {
            Action action = page.slots()[i];
            boolean left = i >= rightSlots;
            int type = left ? leftSlots : rightSlots;
            int relativeIndex = left ? i - rightSlots : i;

            // get color
            FiguraVec3 color = action == null ? null : action.getColor(selected == i);

            // render background texture
            OverlayTexture.values()[type - 1].data[relativeIndex].render(gui, color, left);

            // no icon for null action
            if (action == null)
                continue;

            // convert angle to x and y coordinates
            double angle = getAngle(i);
            double x = Math.cos(angle) * 15 - 4;
            double y = Math.sin(angle) * 15 - 4;

            // render icon
            UIHelper.enableBlend();

            // Color is now implemented through vertex colors rather than the color modulator
            int tintColor = color != null ? ColorUtils.rgbaToIntARGB(FiguraVec4.of(color.x, color.y, color.z, 1.0f)) : -1;
            gui.blit(RenderPipelines.GUI_TEXTURED, ICONS,
                    (int) Math.round(x), (int) Math.round(y),
                    action.scroll != null ? 24f : action.toggle != null ? action.isToggled() ? 16f : 8f : 0f, color == null ? 0f : 8f,
                    8, 8,
                    8, 8,
                    32, 16,
                    tintColor
            );
        }
    }

    private static void renderItemsAndIcons(GuiGraphicsExtractor gui, Page page) {
        for (int i = 0; i < slots; i++) {
            Action action = page.slots()[i];
            if (action == null)
                continue;

            boolean isSelected = selected == i;

            // convert angle to x and y coordinates
            double angle = getAngle(i);
            double xOff = Math.cos(angle) * DISTANCE;
            double yOff = Math.sin(angle) * DISTANCE;

            // texture
            Action.TextureData texture = action.getTexture(isSelected);
            if (texture != null) {
                UIHelper.enableBlend();
                gui.blit(RenderPipelines.GUI_TEXTURED, texture.texture.getLocation(),
                        (int) Math.round(xOff - texture.width * texture.scale / 2d),
                        (int) Math.round(yOff - texture.height * texture.scale / 2d),
                        (float) texture.u, (float) texture.v,
                        (int) Math.round(texture.width * texture.scale), (int) Math.round(texture.height * texture.scale),
                        texture.width, texture.height,
                        texture.texture.getWidth(), texture.texture.getHeight());
            }

            // no item, no render
            ItemStack item = action.getItem(isSelected);
            if (item == null || item.isEmpty())
                continue;

            // render
            gui.item(item, (int) Math.round(xOff - 8), (int) Math.round(yOff - 8));
            if (Configs.ACTION_WHEEL_DECORATIONS.value)
                gui.itemDecorations(minecraft.font, item, (int) Math.round(xOff - 8), (int) Math.round(yOff - 8));
        }
    }

    private static void renderTexts(GuiGraphicsExtractor gui, Page page) {
        Font font = minecraft.font;
        int titlePosition = Configs.ACTION_WHEEL_TITLE.value;
        int indicatorPosition = Configs.ACTION_WHEEL_SLOTS_INDICATOR.value;
        Matrix3x2fStack pose = gui.pose();

        Action selectedTitleAction = selected == -1 ? null : page.slots()[selected];
        String selectedTitle = selectedTitleAction == null ? null : selectedTitleAction.getTitle();

        // page indicator
        int groupCount = page.getGroupCount();
        if (groupCount > 1 && (selectedTitle == null || indicatorPosition != titlePosition - 2)) {
            pose.pushMatrix();
            //pose.translate(0d, 0d, 999d); there is no z component anymore
            int index = page.getSlotsShift();
            int greatest = page.getGreatestSlot() + 1;

            MutableComponent indicator = Component.empty();
            int extraWidth = 0;

            // down arrow
            if (index > 1) {
                Component arrow = UIHelper.UP_ARROW.copy().append(" ");
                indicator.append(arrow);
                extraWidth -= font.width(arrow);
            }
            // text
            indicator.append(FiguraText.of("gui.action_wheel.slots_indicator",
                    Component.literal(String.valueOf((index - 1) * 8 + 1)).withStyle(FiguraMod.getAccentColor()),
                    Component.literal(String.valueOf(Math.min(index * 8, greatest))).withStyle(FiguraMod.getAccentColor()),
                    Component.literal(String.valueOf(greatest)).withStyle(FiguraMod.getAccentColor())
            ));
            // up arrow
            if (index < groupCount) {
                Component arrow = Component.literal(" ").append(UIHelper.DOWN_ARROW);
                indicator.append(arrow);
                extraWidth += font.width(arrow);
            }

            // draw
            gui.text(font, indicator, x - (int) ((font.width(indicator) - extraWidth) / 2f), (int) Position.index(indicatorPosition).apply(font.lineHeight), UIHelper.adjustColor(0xFFFFFF));
            pose.popMatrix();
        }

        // all titles
        if (titlePosition >= 5) {
            boolean internal = titlePosition == 5;
            double distance = (internal ? DISTANCE : 66) * scale;
            pose.pushMatrix();
            //pose.translate(0f, 0f, 999f);
            for (int i = 0; i < slots; i++) {
                Action action = page.slots()[i];
                if (action == null)
                    continue;

                String title = action.getTitle();
                if (title == null)
                    continue;

                // convert angle to x and y coordinates
                double angle = getAngle(i);
                double xOff = Math.cos(angle) * distance;
                double yOff = Math.sin(angle) * distance;

                // render text
                int textX = x + (int) (Math.round(xOff));
                int textY = y + (int) (Math.round(yOff + (internal ? 9 * scale : -font.lineHeight / 2f)));

                Component text = TextUtils.replaceInText(Emojis.applyEmojis(TextUtils.tryParseJson(title)), "\n|\\\\n", " ");
                int textWidth = font.width(text);

                if (internal) {
                    textX -= textWidth / 2f;
                    if (i >= rightSlots)
                        textX = Math.min(textX, x - textWidth - 1);
                    else
                        textX = Math.max(textX, x + 1);
                } else if (i >= rightSlots) {
                    textX -= textWidth;
                }

                gui.text(font, text, textX, textY, UIHelper.adjustColor(0xFFFFFF));
            }
            pose.popMatrix();
            return;
        }

        // title
        if (selectedTitle == null)
            return;

        // vars
        Component text = Emojis.applyEmojis(TextUtils.tryParseJson(selectedTitle));
        List<Component> list = TextUtils.splitText(text, "\n");
        int height = font.lineHeight * list.size();

        // render
        if (titlePosition < 2) { // tooltip
            UIHelper.renderTooltip(gui, text, (int) mouseX, (int) mouseY, titlePosition == 0);
        } else { // anchored
            pose.pushMatrix();
          //  pose.translate(0f, 0f);

            int y = (int) Position.index(titlePosition - 2).apply(height);
            for (int i = 0; i < list.size(); i++) {
                Component component = list.get(i);
                gui.text(font, component, x - (int) (font.width(component) / 2f), y + font.lineHeight * i, UIHelper.adjustColor(0xFFFFFF));
            }

            pose.popMatrix();
        }
    }

    // -- functions -- // 

    public static void execute(int index, boolean left) {
        if (isEnabled()) {
            var outfit = currentOutfit();
            if (outfit != null) {
                withOutfitBudget(outfit, () -> outfitWheel.execute(outfit.base(), index, left));
                selected = -1;
                return;
            }
        }
        Avatar avatar;
        if (!isEnabled() || (avatar = AvatarManager.getAvatarForPlayer(FiguraMod.getLocalPlayerUUID())) == null || avatar.luaRuntime == null) {
            selected = -1;
            return;
        }

        // wheel click action
        if (avatar.luaRuntime.action_wheel.execute(avatar, left))
            return;

        // execute action
        Page currentPage;
        if (index < 0 || index > 7 || avatar.luaRuntime == null || (currentPage = avatar.luaRuntime.action_wheel.currentPage) == null) {
            selected = -1;
            return;
        }

        Action action = currentPage.slots()[index];
        if (action != null) action.execute(avatar, left, YSM_PRESS);

        selected = -1;
    }

    public static void hotbarKeyPressed(int i) {
        execute(i, true);
    }

    public static void scroll(double delta) {
        if (isEnabled()) {
            var outfit = currentOutfit();
            if (outfit != null) {
                withOutfitBudget(outfit, () -> outfitWheel.scroll(outfit.base(), selected, delta));
                return;
            }
        }
        Avatar avatar;
        if (!isEnabled() || (avatar = AvatarManager.getAvatarForPlayer(FiguraMod.getLocalPlayerUUID())) == null || avatar.luaRuntime == null)
            return;

        // wheel scroll action
        if (avatar.luaRuntime.action_wheel.mouseScroll(avatar, delta))
            return;

        // scroll action
        Page currentPage;
        if (avatar.luaRuntime == null || (currentPage = avatar.luaRuntime.action_wheel.currentPage) == null)
            return;

        if (selected >= 0 && selected <= 7) {
            Action action = currentPage.slots()[selected];
            if (action != null && action.scroll != null) {
                action.mouseScroll(avatar, delta);
                return;
            }
        }

        // page scroll
        currentPage.setSlotsShift(currentPage.getSlotsShift() - (int) Math.signum(delta));
    }

    public static void setEnabled(boolean enabled) {
        if (!enabled) {
            releaseYsmPress();
        }
        ActionWheel.enabled = enabled;
    }

    public static void releaseYsmPress() {
        YSM_PRESS.release();
        if (outfitWheel != null) {
            outfitWheel.release();
        }
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static int getSelected() {
        return selected;
    }

    // -- overlay texture data -- // 

    private enum OverlayTexture {
        ONE(
                new TextureData(true, -64, 0, 0, 0)
        ),
        TWO(
                new TextureData(64, 0),
                new TextureData(64, 0, 90)
        ),
        THREE(
                new TextureData(128, 0),
                new TextureData(-32, 128, 64, 0),
                new TextureData(0, 64, 64, 0)
        ),
        FOUR(
                new TextureData(192, 0),
                new TextureData(192, 64),
                new TextureData(192, 0, 90),
                new TextureData(192, 64, 90)
        );

        private final TextureData[] data;

        OverlayTexture(TextureData... data) {
            this.data = data;
        }
    }

    private static class TextureData {

        private final int y, h, rh;
        private final float u, v;
        private final int rotation;

        public TextureData(boolean large, int y, float u, float v, int rotation) {
            this.y = y;
            this.h = large ? 128 : 64;
            this.u = u;
            this.v = v;
            this.rh = large ? 128 : 64;
            this.rotation = rotation;
        }

        public TextureData(int y, float u, float v, int rotation) {
            this(false, y, u, v, rotation);
        }

        public TextureData(float u, float v, int rotation) {
            this(-64, u, v, rotation);
        }

        public TextureData(float u, float v) {
            this(u, v, 0);
        }

        public void render(GuiGraphicsExtractor gui, FiguraVec3 color, boolean left) {
            Matrix3x2fStack pose = gui.pose();
            pose.pushMatrix();
            pose.rotate((rotation + (left ? 180 : 0)) * (float) (Math.PI / 180.0));

            UIHelper.enableBlend();
            // we now use vertex colors
            int tintColor = color != null ? ColorUtils.rgbaToIntARGB(FiguraVec4.of(color.x, color.y, color.z, 1.0f)) : -1;
            gui.blit(RenderPipelines.GUI_TEXTURED, TEXTURE, 0, y,  u, color == null ? v : v + 128, 64, h,64, rh, 256, 256, tintColor);

            pose.popMatrix();
        }
    }

    // -- text position -- // 

    private enum Position {
        TOP(height -> Math.max(y - 64 * scale - 4 - height, 4)),
        MID(height -> y - height / 2f),
        BOT(height -> Math.min(y + 64 * scale + 4 + height, y * 2 - 4) - height);

        private final Function<Double, Double> function;

        Position(Function<Double, Double> function) {
            this.function = function;
        }

        public static Position index(int i) {
            return values()[i];
        }

        public double apply(double d) {
            return function.apply(d);
        }
    }
}
