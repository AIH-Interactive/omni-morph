package org.figuramc.figura.avatar;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.ints.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.figuramc.figura.FiguraMod;
import top.aihmc.omnimorph.avatar.ysm.YsmAvatarDetector;
import org.figuramc.figura.avatar.local.LocalAvatarLoader;
import org.figuramc.figura.backend2.NetworkStuff;
import top.aihmc.omnimorph.ducks.FiguraEntityRenderStateExtension;
import org.figuramc.figura.gui.FiguraToast;
import org.figuramc.figura.gui.widgets.lists.AvatarList;
import org.figuramc.figura.lua.api.particle.ParticleAPI;
import org.figuramc.figura.lua.api.sound.SoundAPI;
import org.figuramc.figura.lua.api.world.WorldAPI;
import top.aihmc.omnimorph.model.library.LibraryPreviewBinding;
import top.aihmc.omnimorph.render.RenderLifetime;
import org.figuramc.figura.utils.EntityUtils;
import org.figuramc.figura.utils.FiguraClientCommandSource;
import org.figuramc.figura.utils.FiguraResourceListener;
import org.figuramc.figura.utils.FiguraText;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import top.aihmc.omnimorph.avatar.AvatarLoadProgress;
/**
 * Manages all the avatars that are currently loaded in memory, and also
 * handles getting the avatars of entities. If an entity does not have a loaded avatar,
 * the AvatarManager will fetch the avatar and cache it.
 */
public class AvatarManager {

    private static final Map<UUID, UserData> LOADED_USERS = new ConcurrentHashMap<>();
    private static final Set<UUID> FETCHED_USERS = new HashSet<>();

    private static final Int2ObjectMap<Avatar> LOADED_CEM = new Int2ObjectOpenHashMap<>();

    public static final FiguraResourceListener RESOURCE_RELOAD_EVENT = FiguraResourceListener.createResourceListener("resource_reload_event", manager -> {
        top.aihmc.omnimorph.model.ysm.animation.YsmDefaultAnimationResolver.clear();
        RenderLifetime.INSTANCE.invalidateResources();
        executeAll("resourceReloadEvent", Avatar::resourceReloadEvent);
    });

    public static boolean localUploaded = true; // init as true :3
    public static boolean panic = false;

    // Added to reduce look up for entities + fixes trident and arrow that no longer exist in world not being rendered while picked up
    public static Int2ObjectMap<Entity> ENTITY_CACHE = new Int2ObjectOpenHashMap<>();

    // -- panic mode -- // 

    public static void togglePanic() {
        AvatarManager.panic = !AvatarManager.panic;
        FiguraToast.sendToast(FiguraText.of(AvatarManager.panic ? "toast.panic_enabled" : "toast.panic_disabled"), FiguraToast.ToastType.WARNING);
        SoundAPI.getSoundEngine().figura$stopAllSounds();
        ParticleAPI.getParticleEngine().figura$clearParticles(null);
    }

    // -- avatar events -- // 

    public static void tickLoadedAvatars() {
        top.aihmc.omnimorph.model.outfit.LocalOutfitPreview.tick();
        if (panic)
            return;

        // tick the avatars
        for (UserData user : LOADED_USERS.values()) {
            Avatar avatar = user.getMainAvatar();
            if (avatar != null || user.getOutfit() != null) {
                if (avatar == null) {
                    user.tick();
                    continue;
                }
                FiguraMod.pushProfiler(avatar);
                user.tick();
                FiguraMod.popProfiler();
            }
        }

        // CEM
        if (LOADED_CEM.isEmpty())
            return;

        // unload entities
        IntSet toBeRemoved = new IntOpenHashSet();

        for (int entityId : LOADED_CEM.keySet()) {
            Entity entity = Minecraft.getInstance().level.getEntity(entityId);
            if (entity != null && entity.isRemoved()) {
                toBeRemoved.add(entityId);
                ENTITY_CACHE.remove(entityId);
            } else if (entity == null) {
                ENTITY_CACHE.remove(entityId);
            }
        }

        for (int entity : toBeRemoved)
            LOADED_CEM.remove(entity);

        // tick entities
        for (Avatar avatar : LOADED_CEM.values()) {
            if (avatar != null) {
                FiguraMod.pushProfiler(avatar);
                avatar.tick();
                FiguraMod.popProfiler();
            }
        }
    }

    public static void executeAll(String src, Consumer<Avatar> consumer) {
        if (panic) return;

        FiguraMod.pushProfiler(FiguraMod.MOD_ID);
        FiguraMod.pushProfiler(src);

        for (UserData user : LOADED_USERS.values()) {
            Avatar avatar = user.getMainAvatar();
            UserData.OutfitState outfit = user.getOutfit();
            if (outfit != null) {
                outfit.composition().executeAll(outfit.base(), consumer);
            } else if (avatar != null) {
                FiguraMod.pushProfiler(avatar);
                consumer.accept(avatar);
                FiguraMod.popProfiler();
            }
        }

        for (Avatar avatar : LOADED_CEM.values()) {
            if (avatar != null) {
                FiguraMod.pushProfiler(avatar);
                consumer.accept(avatar);
                FiguraMod.popProfiler();
            }
        }

        FiguraMod.popProfiler(2);
    }

    // -- avatar getters -- // 

    public static UserData.OutfitState getLoadedOutfit(UUID owner) {
        UserData user = LOADED_USERS.get(owner);
        return user == null || panic ? null : user.getOutfit();
    }

    /** Inspect the resident loading identity without fetching a profile or creating a user. */
    public static UserData getLoadedUser(UUID owner) {
        return LOADED_USERS.get(owner);
    }

    // player will also attempt to load from network, if possible
    public static Avatar getAvatarForPlayer(UUID player) {
        if (LibraryPreviewBinding.isVanilla(player)) {
            return null;
        }
        Avatar preview = LibraryPreviewBinding.avatar(player);
        if (preview != null && !panic) {
            return preview;
        }
        if (panic || Minecraft.getInstance().level == null)
            return null;

        fetchBackend(player);

        UserData user = LOADED_USERS.get(player);
        return user == null ? null : user.getMainAvatar();
    }

    private static Avatar getAvatarForEntity(Entity entity) {
        // get loaded
        Avatar loaded = LOADED_CEM.get(entity.getId());
        if (loaded != null)
            return loaded;

        // new avatar
        Identifier type = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType());
        CompoundTag nbt = LocalAvatarLoader.CEM_AVATARS.get(type);
        return nbt == null ? null : loadEntityAvatar(entity, nbt);
    }

    public static Avatar getAvatar(EntityRenderState state) {
        if (LibraryPreviewBinding.isVanilla(state)) {
            return null;
        }
        Avatar preview = LibraryPreviewBinding.avatar(state);
        if (preview != null && !panic) {
            return preview;
        }
        if (top.aihmc.omnimorph.model.outfit.OutfitRenderBinding.hasFrame(state)) {
            return panic ? null : top.aihmc.omnimorph.model.outfit.OutfitRenderBinding.avatar(state);
        }
        if (panic || Minecraft.getInstance().level == null || state == null) return null;

        if (state instanceof AvatarRenderState playerRenderState) {
            return getAvatar(Minecraft.getInstance().level.getEntity(playerRenderState.id));
        }
        Integer id = ((FiguraEntityRenderStateExtension)state).figura$getEntityId();
        Entity entity = id != null ? Minecraft.getInstance().level.getEntity(id) : null;
        return getAvatar(entity);
    }

    public static Entity getEntity(EntityRenderState state) {
        Entity preview = LibraryPreviewBinding.entity(state);
        if (preview != null) {
            return preview;
        }
        Entity captured = top.aihmc.omnimorph.model.outfit.OutfitRenderBinding.entity(state);
        if (captured != null) {
            return captured;
        }
        if (Minecraft.getInstance().level == null || state == null) return null;

        if (state instanceof AvatarRenderState playerRenderState) {
            return Minecraft.getInstance().level.getEntity(playerRenderState.id);
        }
        Integer id = ((FiguraEntityRenderStateExtension)state).figura$getEntityId();
        return id != null ? Minecraft.getInstance().level.getEntity(id) : null;
    }

    // tries to get data from an entity
    public static Avatar getAvatar(Entity entity) {
        if (LibraryPreviewBinding.isVanilla(entity)) {
            return null;
        }
        Avatar preview = LibraryPreviewBinding.avatar(entity);
        if (preview != null && !panic) {
            return preview;
        }
        if (panic || Minecraft.getInstance().level == null || entity == null)
            return null;

        UUID uuid = entity.getUUID();

        // load from player (fetch backend) if is a player
        if (entity instanceof Player){
            Avatar avatar = getAvatarForPlayer(uuid);
            if (avatar != null)
                return avatar;
        }

        // otherwise check for CEM
        return getAvatarForEntity(entity);
    }

    // get a loaded avatar without fetching backend or creating a new one
    public static Avatar getLoadedAvatar(UUID owner) {
        if (panic || Minecraft.getInstance().level == null)
            return null;

        UserData user = LOADED_USERS.get(owner);
        return user == null ? null : user.getMainAvatar();
    }

    public static AvatarLoadProgress.Snapshot getLoadingProgress(UUID owner) {
        UserData user = LOADED_USERS.get(owner);
        return user == null ? null : user.loading.snapshot();
    }

    public static void clearLoadingProgress(UUID owner) {
        UserData user = LOADED_USERS.get(owner);
        if (user != null) {
            user.loading.clear();
        }
    }

    public static void clearNetworkLoadingProgress() {
        LOADED_USERS.values().forEach(user -> user.loading.clearNetwork());
    }

    // get all main loaded avatars
    public static List<Avatar> getLoadedAvatars() {
        List<Avatar> list = new ArrayList<>();
        for (UserData user : LOADED_USERS.values()) {
            Avatar avatar = user.getMainAvatar();
            if (avatar != null && avatar.nbt != null)
                list.add(avatar);
        }
        return list;
    }

    // -- avatar management -- // 

    // removes an loaded avatar
    public static void clearAvatars(UUID id) {
        FETCHED_USERS.remove(id);

        UserData user = LOADED_USERS.get(id);
        if (user != null) user.clear();

        NetworkStuff.clear(id);
        FiguraMod.debug("Cleared avatars of " + id);
    }

    public static void clearCEMAvatars() {
        for (Avatar avatar : LOADED_CEM.values())
            avatar.clean();
        LOADED_CEM.clear();
    }

    // clears ALL loaded avatars, including local
    public static void clearAllAvatars() {
        NetworkStuff.localSelectionChanged();
        for (UUID id : LOADED_USERS.keySet())
            clearAvatars(id);

        LOADED_USERS.clear();
        FETCHED_USERS.clear();
        ENTITY_CACHE.clear();
        clearCEMAvatars();

        localUploaded = true;
        AvatarList.selectedEntry = null;
        LocalAvatarLoader.loadAvatar(null, null);
        FiguraMod.LOGGER.info("Cleared all avatars");
    }

    // reloads an avatar
    public static void reloadAvatar(UUID id) {
        if (FiguraMod.isLocal(id) && LocalAvatarLoader.getLastLoadedPath() != null)
            loadLocalAvatar(LocalAvatarLoader.getLastLoadedPath());
        else {
            NetworkStuff.clear(id);
            FETCHED_USERS.add(id);
            UserData user = LOADED_USERS.computeIfAbsent(id, UserData::new);
            NetworkStuff.getUser(user);
        }
    }

    public static void reloadAllAvatars() {
        for (UUID id : List.copyOf(LOADED_USERS.keySet())) {
            reloadAvatar(id);
        }
        clearCEMAvatars();
    }

    /** Retire pending preparation without removing the visible model during a library equip request. */
    public static void cancelPendingLocalLoad() {
        UserData user = LOADED_USERS.get(FiguraMod.getLocalPlayerUUID());
        if (user != null) {
            user.ysmLoads.begin();
        }
    }

    /** One client-thread preparation generation, including vanilla outfits without a base Avatar. */
    public record OutfitLoad(UserData user, long generation) {
        public boolean current() {
            return user.id.equals(FiguraMod.getLocalPlayerUUID()) && LOADED_USERS.get(user.id) == user
                    && user.ysmLoads.current(generation);
        }

        public CompletableFuture<Boolean> publish(top.aihmc.omnimorph.model.outfit.OutfitConfig configuration,
                                                   Avatar base, top.aihmc.omnimorph.model.outfit.OutfitComposition composition,
                                                   BooleanSupplier current) {
            return user.publishOutfit(configuration, base, composition, generation,
                    () -> current() && current.getAsBoolean()).thenApply(published -> {
                if (published) {
                    LocalAvatarLoader.loadAvatar(null, null);
                    AvatarList.selectedEntry = null;
                    FETCHED_USERS.add(user.id);
                    localUploaded = true;
                }
                return published;
            });
        }
    }

    public static OutfitLoad beginOutfitLoad() {
        UUID player = FiguraMod.getLocalPlayerUUID();
        UserData user = LOADED_USERS.computeIfAbsent(player, UserData::new);
        return new OutfitLoad(user, user.ysmLoads.begin());
    }

    /** Client-thread publication after a source-bound equip commit and successful worker preparation. */
    public static CompletableFuture<Boolean> publishLibraryAvatar(Avatar prepared, BooleanSupplier current) {
        UUID player = FiguraMod.getLocalPlayerUUID();
        if (!player.equals(prepared.owner)) {
            prepared.clean();
            return CompletableFuture.completedFuture(false);
        }
        UserData user = LOADED_USERS.computeIfAbsent(player, UserData::new);
        return user.publishAvatar(prepared, user.ysmLoads.begin(), current).thenApply(published -> {
            if (published) {
                LocalAvatarLoader.loadAvatar(null, null);
                AvatarList.selectedEntry = null;
                FETCHED_USERS.add(player);
                localUploaded = true;
            }
            return published;
        });
    }

    /** The wardrobe refresh explicitly leaves local preview mode and reads this player's cloud equipment. */
    public static void reloadCloudAvatar() {
        UUID id = FiguraMod.getLocalPlayerUUID();
        NetworkStuff.localSelectionChanged();
        LocalAvatarLoader.loadAvatar(null, null);
        AvatarList.selectedEntry = null;
        UserData user = LOADED_USERS.computeIfAbsent(id, UserData::new);
        user.ysmLoads.begin();
        NetworkStuff.clear(id);
        FETCHED_USERS.add(id);
        if (!NetworkStuff.isConnected()) {
            NetworkStuff.auth();
        }
        NetworkStuff.getUser(user);
    }

    // load the local player avatar
    public static void loadLocalAvatar(Path path) {
        UUID id = FiguraMod.getLocalPlayerUUID();
        NetworkStuff.localSelectionChanged();

        // Retire cloud callbacks even when the previous model stays visible during preparation.
        NetworkStuff.clear(id);
        if (path == null) {
            clearAvatars(id);
        }
        FETCHED_USERS.add(id);

        // load
        UserData user = LOADED_USERS.computeIfAbsent(id, UserData::new);
        LocalAvatarLoader.loadAvatar(path, user);

        // mark as not uploaded
        localUploaded = false;
        if (path == null) {
            NetworkStuff.localAvatarReady(null);
        }
    }

    // load CEM avatar
    public static Avatar loadEntityAvatar(Entity entity, CompoundTag nbt) {
        Avatar targetAvatar = new Avatar(entity);
        targetAvatar.load(nbt);
        LOADED_CEM.put(entity.getId(), targetAvatar);
        AvatarManager.ENTITY_CACHE.putIfAbsent(entity.getId(), entity);
        return targetAvatar;
    }

    // load CEM avatar
    public static Avatar loadEntityAvatar(EntityRenderState entity, CompoundTag nbt) {
        Avatar targetAvatar = new Avatar(entity);
        targetAvatar.load(nbt);
        Integer id = entity instanceof AvatarRenderState playerRenderState ? playerRenderState.id : ((FiguraEntityRenderStateExtension)entity).figura$getEntityId();
        LOADED_CEM.put(id, targetAvatar);
        AvatarManager.ENTITY_CACHE.putIfAbsent(id, WorldAPI.getCurrentWorld().getEntity(id));
        return targetAvatar;
    }

    // set an user's avatar
    public static void setAvatar(UUID id, CompoundTag nbt) {
        try {
            UserData user = LOADED_USERS.computeIfAbsent(id, UserData::new);
            clearAvatars(id);
            user.loadAvatar(nbt);
        } catch (Exception e) {
            FiguraMod.LOGGER.error("Failed to set avatar for " + id, e);
        }
    }

    // get avatar from the backend
    private static void fetchBackend(UUID id) {
        if (FETCHED_USERS.contains(id))
            return;

        FETCHED_USERS.add(id);

        if (EntityUtils.checkInvalidPlayer(id)) {
            FiguraMod.debug("Voiding userdata for " + id);
            return;
        }

        UserData user = LOADED_USERS.computeIfAbsent(id, UserData::new);

        FiguraMod.debug("Getting userdata for " + id);
        NetworkStuff.getUser(user);
    }

    // -- badges -- // 

    public static Pair<BitSet, BitSet> getBadges(UUID id) {
        UserData user = LOADED_USERS.get(id);
        if (user == null)
            return null;

        Pair<BitSet, BitSet> badges = user.getBadges();
        if (badges != null)
            return badges;

        badges = Badges.emptyBadges();
        user.loadBadges(badges);
        return badges;
    }

    // -- command -- // 

    public static LiteralArgumentBuilder<FiguraClientCommandSource> getCommand() {
        // root
        LiteralArgumentBuilder<FiguraClientCommandSource> root = LiteralArgumentBuilder.literal("set_avatar");

        // source
        RequiredArgumentBuilder<FiguraClientCommandSource, String> target = RequiredArgumentBuilder.argument("target", StringArgumentType.word());

        // target
        RequiredArgumentBuilder<FiguraClientCommandSource, String> source = RequiredArgumentBuilder.argument("source", StringArgumentType.word());
        source.executes(context -> {
            String s = StringArgumentType.getString(context, "source");
            String t = StringArgumentType.getString(context, "target");

            UUID sourceUUID, targetUUID;
            try {
                sourceUUID = UUID.fromString(s);
                targetUUID = UUID.fromString(t);
            } catch (Exception e) {
                context.getSource().figura$sendError(Component.literal("Failed to parse uuids"));
                return 0;
            }

            UserData user = LOADED_USERS.get(sourceUUID);
            Avatar avatar = user == null ? null : user.getMainAvatar();
            if (avatar == null || avatar.nbt == null) {
                context.getSource().figura$sendError(Component.literal("No source Avatar found"));
                return 0;
            }

            if (LOADED_USERS.get(targetUUID) != null) {
                setAvatar(targetUUID, avatar.nbt);
                if (FiguraMod.isLocal(targetUUID))
                    localUploaded = true;
                context.getSource().figura$sendFeedback(Component.literal("Set avatar for " + t));
                return 1;
            }

            Entity targetEntity = EntityUtils.getEntityByUUID(targetUUID);
            if (targetEntity == null) {
                context.getSource().figura$sendError(Component.literal("Target entity not found"));
                return 0;
            }

            loadEntityAvatar(targetEntity, avatar.nbt);
            return 1;
        });
        target.then(source);

        // build root
        root.then(target);
        return root;
    }
}
