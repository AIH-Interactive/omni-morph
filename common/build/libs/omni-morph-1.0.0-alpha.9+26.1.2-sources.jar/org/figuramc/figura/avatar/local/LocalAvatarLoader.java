package org.figuramc.figura.avatar.local;


import net.minecraft.nbt.*;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.util.Util;
import org.figuramc.figura.FiguraMod;
import org.figuramc.figura.avatar.AvatarManager;
import org.figuramc.figura.avatar.UserData;
import top.aihmc.omnimorph.avatar.ysm.YsmAvatarDetector;
import top.aihmc.omnimorph.avatar.ysm.YsmAvatarLoader;
import org.figuramc.figura.gui.FiguraToast;
import org.figuramc.figura.parsers.AvatarMetadataParser;
import org.figuramc.figura.parsers.BlockbenchCommonTypes;
import org.figuramc.figura.parsers.BlockbenchParser2;
import org.figuramc.figura.parsers.LuaScriptParser;
import org.figuramc.figura.parsers.ModelParseResult;
import org.figuramc.figura.utils.FiguraResourceListener;
import org.figuramc.figura.utils.FiguraText;
import org.figuramc.figura.utils.IOUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;

import top.aihmc.omnimorph.avatar.local.LocalAvatarSource;
/**
 * class used to load avatars from a file
 * and used for hot-swapping
 */
public class LocalAvatarLoader {

    public static final boolean IS_WINDOWS = Util.getPlatform() == Util.OS.WINDOWS;
    private static final HashMap<Path, WatchKey> KEYS = new HashMap<>();

    private static CompletableFuture<Void> tasks;
    private static Path lastLoadedPath;
    private static LoadState loadState = LoadState.UNKNOWN;
    private static String loadError;

    private static WatchService watcher;

    public static final HashMap<Identifier, CompoundTag> CEM_AVATARS = new HashMap<>();
    public static final FiguraResourceListener AVATAR_LISTENER = FiguraResourceListener.createResourceListener("cem", manager -> {
        CEM_AVATARS.clear();
        AvatarManager.clearCEMAvatars();

        for (Map.Entry<Identifier, Resource> cem : manager.listResources("cem", location -> location.getNamespace().equals(FiguraMod.MOD_ID) && location.getPath().endsWith(".nbt")).entrySet()) {
            // id
            Identifier key = cem.getKey();
            String[] split = key.getPath().split("/");
            if (split.length <= 1)
                continue;

            String namespace = split[split.length - 2];
            String path = split[split.length - 1];
            // This is a 4 because .nbt has 4 characters
            Identifier id = new Identifier(namespace, path.substring(0, path.length() - 4));

            // nbt
            CompoundTag nbt;
            try {
                nbt = NbtIo.readCompressed(cem.getValue().open(), NbtAccounter.unlimitedHeap());
            } catch (Exception e) {
                FiguraMod.LOGGER.error("Failed to load " + id + " avatar", e);
                continue;
            }

            // insert
            FiguraMod.LOGGER.info("Loaded CEM model for " + id);
            CEM_AVATARS.put(id, nbt);
        }
    });

    static {
        try {
            watcher = FileSystems.getDefault().newWatchService();
        } catch (Exception e) {
            FiguraMod.LOGGER.error("Failed to initialize the watcher service", e);
        }
    }

    protected static synchronized void async(Runnable toRun) {
        if (tasks == null || tasks.isDone()) {
            tasks = CompletableFuture.runAsync(toRun);
        } else {
            tasks = tasks.handle((ignored, failure) -> null).thenRunAsync(toRun);
        }
    }

    /**
     * Loads an NbtCompound from the specified path
     *
     * @param path - the file/folder for loading the avatar
     */
    public static void loadAvatar(Path path, UserData target) {
        loadError = null;
        loadState = LoadState.UNKNOWN;
        resetWatchKeys();
        try {
            path = path == null ? null : path.getFileSystem() == FileSystems.getDefault() ? Path.of(path.toFile().getCanonicalPath()) : path.normalize();
        } catch (IOException e) {
        }
        lastLoadedPath = path;

        if (path == null || target == null)
            return;

        long generation = target.ysmLoads.begin();
        long progress = target.loading.begin(top.aihmc.omnimorph.avatar.AvatarLoadProgress.Stage.READING);
        addWatchKey(path, KEYS::put);

        Path finalPath = path;
        if (YsmAvatarDetector.isYsmAvatar(finalPath)) {
            YsmAvatarLoader.loadAvatar(finalPath, target);
            return;
        }

        async(() -> {
            try {
                FiguraMod.debug("--- avatar compiling: " + target.id + " ---");
                var source = LocalAvatarSource.capture(finalPath, () -> !target.ysmLoads.current(generation));
                CompoundTag nbt = compileFiguraAvatar(finalPath, target.id);
                LocalAvatarSource.verify(finalPath, source, () -> !target.ysmLoads.current(generation));

                // load
                net.minecraft.client.Minecraft.getInstance().execute(() -> {
                    if (target.ysmLoads.current(generation)) {
                        target.loadAvatar(nbt, () -> true, source).thenAccept(published -> {
                            if (published) {
                                org.figuramc.figura.backend2.NetworkStuff.localAvatarReady(target.getMainAvatar());
                            }
                        });
                    }
                    target.loading.finish(progress);
                });
            } catch (Throwable e) {
                target.loading.finish(progress);
                loadError = e.getMessage();
                FiguraMod.LOGGER.error("Failed to load avatar from " + finalPath, e);
                FiguraToast.sendToast(FiguraText.of("toast.load_error"), FiguraText.of("gui.load_error." + LocalAvatarLoader.getLoadState()), FiguraToast.ToastType.ERROR);
            }
        });
    }

    public static CompoundTag compileFiguraAvatar(Path path, UUID owner) throws Exception {
        return compileFiguraAvatar(path, owner, true);
    }

    /** Library preparation does not change wardrobe progress, watchers or the selected avatar. */
    public static CompoundTag prepareFiguraAvatar(Path path, UUID owner) throws Exception {
        return compileFiguraAvatar(path, owner, false);
    }

    /** Accessory preparation shares the native compiler and explicitly selects its manifest. */
    public static CompoundTag prepareCosmeticAvatar(Path path, UUID owner) throws Exception {
        return compileFiguraAvatar(path, owner, false, "cosmetic.json");
    }

    private static CompoundTag compileFiguraAvatar(Path path, UUID owner, boolean reportProgress) throws Exception {
        return compileFiguraAvatar(path, owner, reportProgress, "avatar.json");
    }

    private static CompoundTag compileFiguraAvatar(Path path, UUID owner, boolean reportProgress,
                                                   String manifest) throws Exception {
        // load as folder
        CompoundTag nbt = new CompoundTag();

        // scripts
        if (reportProgress) {
            loadState = LoadState.SCRIPTS;
        }
        loadScripts(path, nbt);

        // custom sounds
        if (reportProgress) {
            loadState = LoadState.SOUNDS;
        }
        loadSounds(path, nbt);

        // models
        CompoundTag textures = new CompoundTag();
        ListTag animations = new ListTag();
        BlockbenchParser2 modelParser = new BlockbenchParser2();

        if (reportProgress) {
            loadState = LoadState.MODELS;
        }
        CompoundTag models = loadModels(path, path, modelParser, textures, animations, "");
        models.putString("name", "models");

        // metadata
        if (reportProgress) {
            loadState = LoadState.METADATA;
        }
        String avatarJson = IOUtils.readFile(path.resolve(manifest));
        var metadata = AvatarMetadataParser.read(avatarJson);
        CompoundTag metadataNbt = AvatarMetadataParser.parse(metadata, avatarJson, IOUtils.getFileNameOrEmpty(path));
        nbt.put("metadata", metadataNbt);
        metadataNbt.putString("uuid", owner.toString());
        if (manifest.equals("cosmetic.json")) {
            top.aihmc.omnimorph.model.outfit.CosmeticMetadata.read(avatarJson);
            metadataNbt.putString("resource_kind", "ACCESSORY");
            metadataNbt.putString("cosmetic_json", avatarJson);
        }

        AvatarMetadataParser.injectToModels(metadata, models);
        AvatarMetadataParser.injectToTextures(metadata, textures);

        // return :3
        if (!models.isEmpty())
            nbt.put("models", models);
        if (!textures.isEmpty())
            nbt.put("textures", textures);
        if (!animations.isEmpty())
            nbt.put("animations", animations);
        CompoundTag metadataTag = nbt.getCompoundOrEmpty("metadata");
        if (metadataTag.contains("resources_paths")) {
            loadResources(nbt, metadataTag.getListOrEmpty("resources_paths"), path);
            metadataTag.remove("resource_paths");
        }

        return nbt;
    }

    private static void loadResources(CompoundTag nbt, ListTag pathsTag, Path parentPath) throws IOException {
        ArrayList<PathMatcher> pathMatchers = new ArrayList<>();
        FileSystem fs = parentPath.getFileSystem();
        for (int i = 0; i < pathsTag.size(); i++) {
            pathMatchers.add(fs.getPathMatcher("glob:".concat(pathsTag.getStringOr(i, ""))));
        }
        Map<String, Path> pathMap = new HashMap<>();
        matchPathsRecursive(pathMap, parentPath, parentPath, pathMatchers);
        CompoundTag resourcesTag = new CompoundTag();
        for (String p:
                pathMap.keySet()) {
            try (var fis = Files.newInputStream(pathMap.get(p))) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                GZIPOutputStream gos = new GZIPOutputStream(baos);
                int i;
                while ((i = fis.read()) != -1) {
                    gos.write(i);
                }
                gos.close();
                resourcesTag.put(unixifyPath(p), new ByteArrayTag(baos.toByteArray()));
                baos.close();
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        nbt.put("resources", resourcesTag);
    }

    private static String unixifyPath(String original) {
        return original.replace('\\', '/');
    }

    private static void matchPathsRecursive(Map<String, Path> pathMap, Path parent, Path current,
                                            ArrayList<PathMatcher> matchers) throws IOException {
        if (Files.isRegularFile(current)) {
            Path relative = parent.toAbsolutePath().relativize(current.toAbsolutePath()).normalize();
            for (PathMatcher m :
                    matchers) {
                if (m.matches(relative)) {
                    pathMap.put(relative.toString(), current);
                    break;
                }
            }
        }
        else {
            try (var children = Files.list(current)) {
                for (Path child : children.toList()) {
                    matchPathsRecursive(pathMap, parent, child, matchers);
                }
            }
        }
    }

    private static void loadScripts(Path path, CompoundTag nbt) throws IOException {
        List<Path> scripts = IOUtils.getFilesByExtension(path, ".lua");
        if (!scripts.isEmpty()) {
            CompoundTag scriptsNbt = new CompoundTag();
            String pathRegex = path.toString().isEmpty() ? "\\Q\\E" : Pattern.quote(path + path.getFileSystem().getSeparator());
            for (Path script : scripts) {
                String name = script.toString()
                        .replaceFirst(pathRegex, "")
                        .replaceAll("[/\\\\]", ".");
                name = name.substring(0, name.length() - 4);
                scriptsNbt.put(name, LuaScriptParser.parseScript(name, IOUtils.readFile(script)));
            }
            nbt.put("scripts", scriptsNbt);
        }
    }

    private static void loadSounds(Path path, CompoundTag nbt) throws IOException {
        List<Path> sounds = IOUtils.getFilesByExtension(path, ".ogg");
        if (!sounds.isEmpty()) {
            CompoundTag soundsNbt = new CompoundTag();
            String pathRegex = Pattern.quote(path.toString().isEmpty() ? path.toString() : path + path.getFileSystem().getSeparator());
            for (Path sound : sounds) {
                String name = sound.toString()
                        .replaceFirst(pathRegex, "")
                        .replaceAll("[/\\\\]", ".");
                name = name.substring(0, name.length() - 4);
                soundsNbt.putByteArray(name, IOUtils.readFileBytes(sound));
            }
            nbt.put("sounds", soundsNbt);
        }
    }

    private static CompoundTag loadModels(Path avatarFolder, Path currentFile, BlockbenchParser2 parser, CompoundTag textures, ListTag animations, String folders) throws Exception {
        CompoundTag result = new CompoundTag();
        List<Path> subFiles = IOUtils.listPaths(currentFile);
        ListTag children = new ListTag();
        if (subFiles != null)
            for (Path file : subFiles) {
                if (IOUtils.isHidden(file))
                    continue;
                String name = IOUtils.getFileNameOrEmpty(file);
                if (Files.isDirectory(file)) {
                    CompoundTag subfolder = loadModels(avatarFolder, file, parser, textures, animations, folders + name + ".");
                    if (!subfolder.isEmpty()) {
                        subfolder.putString("name", name);
                        BlockbenchCommonTypes.parseParent(name, subfolder);
                        children.add(subfolder);
                    }
                } else if (file.toString().toLowerCase(Locale.US).endsWith(".bbmodel")) {
                   ModelParseResult data = parser.parseModel(avatarFolder, file, IOUtils.readFile(file), name.substring(0, name.length() - 8), folders);;
                    children.add(data.modelNbt());
                    animations.addAll(data.animationList());

                    CompoundTag dataTag = data.textures();
                    if (dataTag.isEmpty())
                        continue;

                    if (textures.isEmpty()) {
                        textures.put("data", new ListTag());
                        textures.put("src", new CompoundTag());
                    }

                    textures.getListOrEmpty("data").addAll(dataTag.getListOrEmpty("data"));
                    textures.getCompoundOrEmpty("src").merge(dataTag.getCompoundOrEmpty("src"));
                }
            }

        if (!children.isEmpty())
            result.put("chld", children);

        return result;
    }

    /**
     * Tick the watched key for hotswapping avatars
     */
    public static void tick() {
        WatchEvent<?> event = null;
        boolean reload = false;

        for (Map.Entry<Path, WatchKey> entry : KEYS.entrySet()) {
            WatchKey key = entry.getValue();
            if (!key.isValid())
                continue;

            for (WatchEvent<?> watchEvent : key.pollEvents()) {
                WatchEvent.Kind<?> kind = watchEvent.kind();
                if (kind == StandardWatchEventKinds.OVERFLOW)
                    continue;

                event = watchEvent;
                Path path = entry.getKey().resolve((Path) event.context());
                String name = IOUtils.getFileNameOrEmpty(path);

                if (IOUtils.isHiddenAvatarResource(path) || !(Files.isDirectory(path) || name.matches("(.*(\\.lua|\\.bbmodel|\\.ogg|\\.png|\\.json)$|avatar\\.json|ysm\\.json)")))
                    continue;

                if (kind == StandardWatchEventKinds.ENTRY_CREATE && !IS_WINDOWS)
                    addWatchKey(path, KEYS::put);

                reload = true;
                break;
            }

            if (reload)
                break;
        }

        // reload avatar
        if (reload) {
            FiguraMod.debug("Detected file changes in the Avatar directory (" + event.context().toString() + "), reloading!");
            AvatarManager.loadLocalAvatar(lastLoadedPath);
        }
    }

    public static void resetWatchKeys() {
        lastLoadedPath = null;
        for (WatchKey key : KEYS.values())
            key.cancel();
        KEYS.clear();
    }

    /**
     * register new watch keys
     *
     * @param path the path to register the watch key
     * @param consumer a consumer that will process the watch key and its path
     */
    protected static void addWatchKey(Path path, BiConsumer<Path, WatchKey> consumer) {
        if (watcher == null || path == null || path.getFileSystem() != FileSystems.getDefault())
            return;

        if (!Files.isDirectory(path) || IOUtils.isHidden(path))
            return;

        try {
            WatchEvent.Kind<?>[] events = {StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_DELETE, StandardWatchEventKinds.ENTRY_MODIFY};
            WatchKey key = IS_WINDOWS ? path.register(watcher, events, com.sun.nio.file.ExtendedWatchEventModifier.FILE_TREE) : path.register(watcher, events);

            consumer.accept(path, key);

            List<Path> children = IOUtils.listPaths(path);
            if (children == null || IS_WINDOWS)
                return;

            for (Path child : children)
                addWatchKey(child, consumer);
        } catch (Exception e) {
            FiguraMod.LOGGER.error("Failed to register watcher for " + path, e);
        }
    }

    public static Path getLastLoadedPath() {
        return lastLoadedPath;
    }

    public static String getLoadState() {
        return loadState.name().toLowerCase(Locale.US);
    }

    public static String getLoadError() {
        return loadError;
    }

    private enum LoadState {
        UNKNOWN,
        SCRIPTS,
        SOUNDS,
        MODELS,
        METADATA
    }
}
